-- 1. Nombre total d’appartements vendus au 1er semestre 2020. --

Select count(*) AS nb_vente
from mutation
join bien on bien.idbien = mutation.id_bien
where code_type_local = 2 and date_mutation < '2020-07-01';

-- 2. Le nombre de ventes d’appartement par région pour le 1er semestre 2020.--

SELECT COUNT(*) AS nb_vente_appart,reg  AS region
from mutation
join bien on bien.idbien = mutation.id_bien
join commune on bien.Id_com = commune.idcom
join region on commune.codreg = region.codreg
where code_type_local = 2 and date_mutation  < '2020-07-01'
Group BY reg;

-- 3. Proportion des ventes d’appartements par le nombre de pièces.
 
SELECT bien.nb_pièce AS nombre_pieces,(COUNT(*)/(SELECT COUNT(*) from mutation))*100 as proportion_ventes_appart
FROM bien
     JOIN mutation ON mutation.id_bien = bien.idbien
WHERE mutation.type_mutation ='Vente'                 
GROUP BY nb_pièce

-- 4.Liste des 10 départements où le prix du mètre carré est le plus élevé.

select round(avg(mutation.valeur_fonciere/bien.surface_reelle_bati) ) AS prix_moye_du_metre_carre,
commune.coddep as DEPARTEMENT
FROM Bien  
          join mutation on mutation.id_bien = bien.idbien
          join commune on commune.Idcom = bien.id_com
group by commune.coddep
ORDER BY prix_moye_du_metre_carre DESC
LIMIT 10;

-- 5. Prix moyen du mètre carré d’une maison en Île-de-France.--

select round(avg(mutation.valeur_fonciere/bien.surface_reelle_bati) ) AS prix_moye_du_metre_carre
FROM Bien  
          join mutation on mutation.id_bien = bien.idbien
          join commune on bien.id_com = commune.Idcom
WHERE code_type_local = "1" AND commune.codreg = '11';
 
-- 6. Liste des 10 appartements les plus chers avec la région et le nombre de mètres carrés.

select mutation.valeur_fonciere,bien.surface_reelle_bati,
region.reg as REGION
FROM Bien  
          join mutation on mutation.id_bien = bien.idbien
          join commune on commune.Idcom = bien.id_com
          join region on region.codreg = commune.codreg
where code_type_local = 2
ORDER BY mutation.valeur_fonciere DESC
LIMIT 10;

-- 7. Taux d’évolution du nombre de ventes entre le premier et le second trimestre de 2020.--

With
Table1 AS (
    SELECT COUNT(id_mutation) AS total_vente_trim1 
    FROM mutation 
    WHERE date_mutation < '2020-04-01'),
Table2 AS (
    SELECT COUNT(id_mutation) AS total_vente_trim2
    FROM mutation 
    WHERE date_mutation >= '2020-04-01')
SELECT
     total_vente_trim1,
	 total_vente_trim2,
    ROUND(total_vente_trim2/total_vente_trim1)*100 AS 'Taux evolution nombre vente'
FROM Table1, Table2;

-- 8. Le classement des régions par rapport au prix au mètre carré des appartement de plus de 4 pièces.+

SELECT
    reg AS REGION,
    ROUND(AVG(mutation.valeur_fonciere/bien.surface_reelle_bati),2) AS 'prix_moyen_du_metre_carrée'
FROM 
    bien 
    JOIN mutation ON bien.idbien = mutation.id_bien
    JOIN commune ON bien.Id_com = commune.idcom
    JOIN region on commune.codreg = region.codreg
WHERE bien.code_type_local = 2 
AND bien.nb_pièce > 4
GROUP BY region.reg
ORDER BY 'prix_moyen_du_metre_carrée' DESC;

-- 9. Liste des communes ayant eu au moins 50 ventes au 1er trimestre--

SELECT 
    com AS "Commune", 
    COUNT(*) AS Ventes
FROM bien 
    JOIN mutation
        ON bien.idbien = mutation.id_bien
    JOIN commune 
        ON commune.idcom = bien.id_com
WHERE 
    date_mutation < '2020-04-01' 
GROUP BY commune.com
HAVING COUNT(*) >= 50;

-- 10. Différence en pourcentage du prix au mètre carré entre un appartement de 2 pièces et un appartement de 3 pièces.--

With
Table1 AS (
    SELECT round(avg(mutation.valeur_fonciere/bien.surface_reelle_bati),2) AS prix_mètre_carré_appart_2p
    FROM bien
JOIN mutation ON mutation.id_bien = bien.idbien
    WHERE code_type_local = '2' AND nb_pièce = 2),
Table2 AS (
    SELECT ROUND(avg(mutation.valeur_fonciere/bien.surface_reelle_bati),2) AS prix_mètre_carré_appart_3p
    FROM bien
JOIN mutation ON mutation.id_bien = bien.idbien
     WHERE code_type_local = '2' AND nb_pièce = 3)
SELECT
	 prix_mètre_carré_appart_2p,
     prix_mètre_carré_appart_3p,
     (100-(prix_mètre_carré_appart_3p/prix_mètre_carré_appart_2p)*100)  AS difference_prct_prix_mètre_carré_appart_2p_3p
FROM Table1, Table2;

-- 11. Les moyennes de valeurs foncières pour le top 3 des communes des départements 6, 13, 33, 59 et 69.

with
table1 As (
SELECT round(AVG(valeur_fonciere),2) AS valeur_moy,
commune.com AS commune,commune.coddep,
RANK () OVER(PARTITION BY commune.coddep ORDER BY AVG(mutation.valeur_fonciere) DESC )  rang 
FROM mutation
JOIN Bien ON mutation.id_bien = bien.idbien
JOIN commune ON bien.Id_com = commune.idcom
WHERE commune.coddep IN ("6","13","33","59","69") 
GROUP BY commune.com, commune.coddep
)
Select *
from table1 
where rang <=3

-- 12. Les 20 communes avec le plus de transactions pour 1000 habitants pour les communes qui dépassent les 10 000 habitants.--

SELECT 
    com AS "Commune", 
 rank () over (order by COUNT(*)/1000 DESC) AS Top20
FROM bien 
    JOIN mutation
        ON bien.idbien = mutation.id_bien
    JOIN commune 
        ON commune.idcom = bien.id_com
WHERE 
    commune.ptot > 10000
GROUP BY com
Limit 20;